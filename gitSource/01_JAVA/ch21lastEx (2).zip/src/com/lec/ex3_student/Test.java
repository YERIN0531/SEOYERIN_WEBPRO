package com.lec.ex3_student;

import java.util.Vector;

public class Test {

	public static void main(String[] args) {
		StudentDao dao = StudentDao.getInstance();
		System.out.println("0�а��� ����Ʈ");
		Vector<String> mnames = dao.getMNamelist();
		System.out.println(mnames);
		
		System.out.println("1�й��˻�");
		StudentDto dtos = dao.snogetStudent(2022001);
		System.out.println(dtos);
		
	}
}

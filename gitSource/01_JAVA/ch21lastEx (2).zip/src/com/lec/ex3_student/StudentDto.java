package com.lec.ex3_student;
// �Է¿� : SNAME, MNAME, SCORE
// ������ : SNO, SNAME, MNAME, SCORE
// ��¿� : RANK, SNO, SNAME, MNAME, SCROE 
public class StudentDto {

	private int rank;
	private String sname;
	private String mname;
	private int score;
	private int sno;
	
	public StudentDto() {}
	//�Է¿�
	public StudentDto(String sname, String mname, int score) {
		this.sname = sname;
		this.mname = mname;
		this.score = score;
	}
	//������
	public StudentDto(int sno, String sname, String mname, int score) {
		this.sno = sno;
		this.sname = sname;
		this.mname = mname;
		this.score = score;
	}
	//��¿�
	public StudentDto(int rank, int sno, String sname, String mname, int score) {
		this.rank = rank;
		this.sno = sno;
		this.sname = sname;
		this.mname = mname;
		this.score = score;
	}
	@Override
	public String toString() {
		if(rank!=0) {//��� �̸� �а��� ���� 
			return rank + "��\t"+sname+"\t"+mname+"\t"+score;			
		}else{
			//�й�,�̸�,�а���,����
			return sno + "\t"+sname+"\t"+mname+"\t"+score;
			
		}
		
		
		
		
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	
}

package com.lec.ex3_student;

public class StudentMng {

}

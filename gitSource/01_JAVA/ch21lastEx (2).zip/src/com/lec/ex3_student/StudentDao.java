package com.lec.ex3_student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

public class StudentDao {

	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url 	  = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	public static int SUCCESS = 1;
	public static int FAIL    = 0;
	
	private static StudentDao INSTANCE = null;
	
	public static StudentDao getInstance() {
		if(INSTANCE==null) {
			INSTANCE = new StudentDao();
		}
		return INSTANCE;
	}
	
		private StudentDao() {
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
			}
		}
	

	//0ùȭ�鿡 �����̸��� �޺��ڽ��� �߰�
	public Vector<String> getMNamelist(){
		Vector<String> mnames = new Vector<String>();
		mnames.add(""); //0��° index���� ���� 
		
	  Connection conn = null;
	  Statement  stmt = null;
	  ResultSet  rs   = null;
	  String sql = "SELECT MNAME FROM MAJOR";
	  
	  try {
		conn = DriverManager.getConnection(url,"scott","tiger");
		stmt = conn.createStatement();
		rs   = stmt.executeQuery(sql);
		while(rs.next()) {
			String mname = rs.getString("mname");
			mnames.add(mname);
		}
	} catch (SQLException e) {
		System.out.println(e.getMessage());
	}finally {
		try {
			if(rs!=null)rs.close();
			if(stmt!=null) stmt.close();
			if(conn!=null) conn.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
		return mnames;
	}
	
	// 1. �й��˻� 
	
	public StudentDto snogetStudent(int sno) {
		StudentDto dto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT SNO, SNAME, MNAME, SCORE" + 
				" FROM STUDENT S , MAJOR M" + 
				" WHERE S.MNO=M.MNO AND SNO=?";

		
		try {
			conn = DriverManager.getConnection(url,"scott","tiger");
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sno);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				String sname = rs.getString("sname");
				String mname = rs.getString("mname");
				int score = rs.getInt("score");
				dto = new StudentDto(sno, sname, mname, score);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
		return dto;
	}
	
	//2�� �̸��˻�(sno,sname,mname,score)
	public ArrayList<StudentDto> snamegetStudent(String sname){
		ArrayList<StudentDto> dto = new ArrayList<StudentDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		return dto;
	}
	
	
	
}












